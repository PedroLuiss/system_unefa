"use strict";
;(function ($) { $.fn.datepicker.language['es'] = {
    days: ['Domingo', 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado'],
    daysShort: ['D', 'L', 'M', 'X', 'J', 'V', 'S'],
    daysMin: ['D', 'L', 'M', 'X', 'J', 'V', 'S'],
    months: ['Enero','Febrero','Marzo','Abril','Mayo','Junio', 'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'],
    monthsShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
    today: 'Hoy',
    clear: 'Limpiar',
    dateFormat: 'dd-mm-yyyy',
    timeFormat: 'hh:ii aa',
    firstDay: 0
}; })(jQuery);