<?php
return [
    // The default css class value if the request match given route name
    'class' => 'active',
];
